

def print_header_tile(t, w, h):
    ret = ""
    ret += ("+-----------+\n")
    ret += (f"{'| Tile:' : <9}{'%d |' : >5}\n" % t)
    ret += (f"{'| Width:' : <9}{'%d |' : >5}\n" % w)
    ret += (f"{'| Height:' : <9}{'%d |' : >5}\n" % h)
    for i in range(len("+-----------+\n")):
        if i == 0 or i == w+1 or i == len("+-----------+\n")-2:
            ret += "+"
        elif i == len("+-----------+\n")-1:
            ret += "\n"
        else:
            ret += "-"
    print(ret, end="")
    return ret


def print_tile(tile_number, tile_body):
    width = max(len(i) for i in tile_body)
    height = len(tile_body)

    print_header_tile(tile_number, width, height)
    for t in range(height-1, -1, -1):
        #print("|"+tile_body[t]+"|")
        print("|"+f"{tile_body[t] : >{width}}"+"|")
    print("+"+"-"*width+"+")



if __name__ == '__main__':
    # print_header_tile(1, 2, 3)
    #
    # print_tile(3, ["blob", "bo"])
    tile_number = 1
    tile = []
    while(True):
        try:
            line = input().split()
        except EOFError:
            if len(tile) > 0:
                print_tile(tile_number, tile)
            exit(0)
        for i in range(0, len(line)):
            if len(tile) == 0:
                tile.append(line[0])
            elif len(line[i]) <= len(line[i-1]):
                tile.append(line[i])
            else:
                print_tile(tile_number, tile)
                tile.clear()
                tile.append(line[i])
                tile_number += 1


